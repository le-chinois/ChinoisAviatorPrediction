# Chinois Chinois Aviator Prediction V2

Prototype Android Kotlin + Jetpack Compose.

## Fonctionnalités
- Accueil professionnel
- Saisie de coefficients et historique local
- Analyse statistique sur les 50 derniers coefficients
- Signal FAIBLE / MODÉRÉ / ÉLEVÉ
- Indice 0–100 (pas une probabilité)
- Plage observée Q1–Q3
- Paramètres et effacement des données

## Compilation
Ouvrir le dossier dans Android Studio avec JDK 17 et Android SDK 35, synchroniser Gradle puis Build > Generate APKs.

Cette application est un outil statistique expérimental : elle ne peut pas garantir ni prédire avec certitude le prochain résultat d'un jeu de type crash.


## V2.1 — CHINOIS AVIATOR PREDICTION

Branding added: application name, launcher icon, dark/red visual identity, and version 2.1.

### Build APK
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Ensure a JDK and Android SDK are installed.
4. Use **Build > Generate App Bundles or APKs > Generate APKs** for a test APK.
5. For a distributable release, create/configure a signing key and build the release variant.

The app is an historical/statistical analysis tool. It does not guarantee or know the next Aviator coefficient.

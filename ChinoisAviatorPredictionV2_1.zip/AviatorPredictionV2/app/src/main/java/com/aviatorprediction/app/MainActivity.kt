package com.aviatorprediction.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.aviatorprediction.app.model.AnalysisResult
import com.aviatorprediction.app.viewmodel.AviatorViewModel

private val Bg=Color(0xFF0B0D10); private val Card=Color(0xFF15191F); private val Red=Color(0xFFE53935); private val Green=Color(0xFF43A047)
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);enableEdgeToEdge();setContent{MaterialTheme(colorScheme=darkColorScheme(primary=Red,background=Bg,surface=Card)){App()}}}}
@Composable fun App(vm:AviatorViewModel=viewModel()){val nav=rememberNavController();val values by vm.values.collectAsState();val result by vm.result.collectAsState();Scaffold(containerColor=Bg,bottomBar={NavigationBar(containerColor=Card){listOf("home" to "Accueil","analyse" to "Analyse","history" to "Historique","settings" to "Paramètres").forEach{(r,l)->NavigationBarItem(selected=false,onClick={nav.navigate(r)},icon={},label={Text(l)})}}}){p->NavHost(nav,"home",Modifier.padding(p)){composable("home"){Home(values,result){nav.navigate("analyse")}};composable("analyse"){Analysis(values,result,vm)};composable("history"){History(values,vm)};composable("settings"){Settings(vm)}}}}
@Composable fun Title(t:String,s:String?=null){Column{Text(t,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);s?.let{Text(it,color=Color.LightGray)}}}
@Composable fun Home(v:List<Double>,r:AnalysisResult?,go:()->Unit){LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){item{Title("CHINOIS AVIATOR PREDICTION","V2 • analyse statistique")};item{CardBlock{Text("DERNIER COEFFICIENT",color=Color.Gray);Text(v.lastOrNull()?.let{"%.2fx".format(it)}?:"—",style=MaterialTheme.typography.displaySmall,fontWeight=FontWeight.Bold)}};item{CardBlock{Text("SIGNAL",color=Color.Gray);Text(r?.signal?:"AUCUNE ANALYSE",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);r?.let{Text("Indice ${it.score}/100 • ${it.trend}",color=Color.LightGray)}}};item{Button(onClick=go,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Text("⚡ ANALYSER")}};item{Text("⚠️ L'application donne un indicateur statistique basé sur l'historique saisi. Elle ne garantit pas le prochain coefficient.",color=Color.Gray)}}}
@Composable fun Analysis(v:List<Double>,r:AnalysisResult?,vm:AviatorViewModel){var input by remember{mutableStateOf("")};LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Title("ANALYSE","Ajoute les coefficients observés")};item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){OutlinedTextField(input,{input=it},Modifier.weight(1f),label={Text("Coefficient")},singleLine=true);Button(onClick={vm.add(input);input=""}){Text("+")}}};item{Text("Rounds enregistrés : ${v.size}",color=Color.Gray)};r?.let{item{ResultCard(it)}};item{Button(onClick={vm.analyze},modifier=Modifier.fillMaxWidth()){Text("⚡ NOUVELLE ANALYSE")}}}}
@Composable fun ResultCard(r:AnalysisResult){Card(colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("SIGNAL STATISTIQUE",color=Color.Gray);Text(r.signal,style=MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.Bold);Text("Plage observée : %.2fx – %.2fx".format(r.q1,r.q3));Text("Moyenne %.2fx • Médiane %.2fx".format(r.mean,r.median));Text("Faibles <2x : %.0f%% • Hauts ≥5x : %.0f%%".format(r.lowRate*100,r.highRate*100),color=Color.LightGray);Text("Indice : ${r.score}/100",color=if(r.score>=55)Green else Red,fontWeight=FontWeight.Bold);Text("Cet indice n'est pas une probabilité de gain.",color=Color.Gray)}}}
@Composable fun History(v:List<Double>,vm:AviatorViewModel){Column(Modifier.fillMaxSize().padding(18.dp)){Title("HISTORIQUE","Derniers coefficients enregistrés");Spacer(Modifier.height(12.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick=vm::deleteLast){Text("Supprimer dernier")};OutlinedButton(onClick=vm::clear){Text("Tout effacer")}};Spacer(Modifier.height(10.dp));LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){itemsIndexed(v.reversed()){i,x->Text("${i+1}.   %.2fx".format(x),modifier=Modifier.fillMaxWidth().padding(10.dp))}}}}
@Composable fun Settings(vm:AviatorViewModel){Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){Title("PARAMÈTRES");Text("Fenêtre d'analyse : jusqu'à 50 derniers coefficients");Text("Les données restent sur l'appareil dans cette V2.",color=Color.Gray);Button(onClick=vm::clear){Text("EFFACER LES DONNÉES")};Text("Version 2.0",color=Color.Gray)}}
@Composable fun CardBlock(content:@Composable ColumnScope.()->Unit){Card(colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(18.dp),content=content)}}

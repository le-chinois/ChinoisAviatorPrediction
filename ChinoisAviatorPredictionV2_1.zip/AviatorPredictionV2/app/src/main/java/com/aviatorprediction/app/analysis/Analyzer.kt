package com.aviatorprediction.app.analysis
import com.aviatorprediction.app.model.AnalysisResult
import kotlin.math.abs

object Analyzer {
 fun analyze(values: List<Double>): AnalysisResult? {
  val x=values.filter { it.isFinite() && it>=1.01 }.takeLast(50); if(x.size<3)return null
  val s=x.sorted(); fun pct(p:Double):Double { val pos=(s.size-1)*p; val lo=pos.toInt(); val hi=kotlin.math.ceil(pos).toInt(); return if(lo==hi)s[lo] else s[lo]+(s[hi]-s[lo])*(pos-lo) }
  val mean=x.average(); val median=pct(.5); val q1=pct(.25); val q3=pct(.75)
  val low=x.count{it<2.0}.toDouble()/x.size; val high=x.count{it>=5.0}.toDouble()/x.size
  val recent=x.takeLast(minOf(5,x.size)).average(); val prev=x.dropLast(minOf(5,x.size)).takeLast(5).let{if(it.isEmpty())recent else it.average()}; val delta=recent-prev
  var score=(55 + (0.5-low)*28 + delta.coerceIn(-2.0,2.0)*6 - abs(mean-median)*1.5).toInt().coerceIn(0,100)
  val signal=when {score>=70->"ÉLEVÉ"; score>=55->"MODÉRÉ"; else->"FAIBLE"}
  val trend=when {delta>.15->"HAUSSE RÉCENTE"; delta<-.15->"BAISSE RÉCENTE"; else->"STABLE"}
  return AnalysisResult(mean,median,q1,q3,low,high,score,signal,trend)
 }
}

package com.aviatorprediction.app.data
import android.content.Context
import org.json.JSONArray
class PrefsRepository(context: Context){ private val p=context.getSharedPreferences("aviator",0)
 fun load():List<Double>{ val a=JSONArray(p.getString("values","[]")!!); return List(a.length()){a.getDouble(it)} }
 fun save(v:List<Double>){ val a=JSONArray(); v.forEach{a.put(it)}; p.edit().putString("values",a.toString()).apply() }
}

package com.aviatorprediction.app.model

data class AnalysisResult(val mean: Double, val median: Double, val q1: Double, val q3: Double, val lowRate: Double, val highRate: Double, val score: Int, val signal: String, val trend: String)

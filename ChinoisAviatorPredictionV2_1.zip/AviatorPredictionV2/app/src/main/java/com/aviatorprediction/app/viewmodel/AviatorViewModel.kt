package com.aviatorprediction.app.viewmodel
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.aviatorprediction.app.analysis.Analyzer
import com.aviatorprediction.app.data.PrefsRepository
import com.aviatorprediction.app.model.AnalysisResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class AviatorViewModel(app:Application):AndroidViewModel(app){ private val repo=PrefsRepository(app); private val _values=MutableStateFlow(repo.load()); val values:StateFlow<List<Double>>=_values; private val _result=MutableStateFlow<AnalysisResult?>(Analyzer.analyze(_values.value)); val result:StateFlow<AnalysisResult?>=_result
 fun add(raw:String){ raw.replace(',','.').toDoubleOrNull()?.takeIf{it>=1.01}?.let{val n=(_values.value+it).takeLast(200);_values.value=n;repo.save(n);_result.value=Analyzer.analyze(n)} }
 fun analyze() { _result.value=Analyzer.analyze(_values.value) }
 fun deleteLast(){if(_values.value.isNotEmpty()){_values.value=_values.value.dropLast(1);repo.save(_values.value);analyze()}}
 fun clear(){_values.value=emptyList();repo.save(emptyList());_result.value=null}
}
